﻿Imports Microsoft.AspNetCore.Mvc

<ApiController>
<Route("[action]")>
Public Class BrandController
    Inherits Controller

    <HttpGet>
    Public Async Function GetAllBrand() As Task(Of IActionResult)

        Return Ok("Deneme GetAll")
    End Function

    <HttpGet("/deneme")>
    Public Async Function GetBrand() As Task(Of IActionResult)

        Return Ok("Bilal")


    End Function








End Class
